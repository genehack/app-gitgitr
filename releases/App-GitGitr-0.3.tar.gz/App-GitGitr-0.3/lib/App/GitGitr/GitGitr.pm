package App::GitGitr;
$App::GitGitr::VERSION = '0.3';
BEGIN {
  $App::GitGitr::AUTHORITY = 'cpan:GENEHACK';
}
# ABSTRACT: This space intentially left blank

__END__

=pod

=encoding UTF-8

=head1 NAME

App::GitGitr - This space intentially left blank

=head1 VERSION

version 0.3

=head1 AUTHOR

John SJ Anderson <genehack@genehack.org>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2010 by John SJ Anderson.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut
